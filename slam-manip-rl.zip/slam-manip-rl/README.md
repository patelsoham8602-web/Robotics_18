# SLAM & Robotic Manipulation (Reinforcement Learning)

Submission for the Ground Robotics Problem Statement: SLAM-based autonomous
navigation combined with reinforcement-learning-driven manipulation,
progressing from basic reach/pick-place to obstacle-aware and contact-rich
(peg-in-hole) tasks.

## Approach

The system is split into two stacks that share a map and hand off control
at named stations:

- **Navigation** (SLAM + Nav2) — built on mature, well-tested open-source
  tools (`slam_toolbox`, Nav2) rather than reinventing localization/planning.
- **Manipulation** (PPO-based RL) — a curriculum of five stages: Reach →
  Pick/Place → Obstacle-aware → Peg-in-hole, each warm-starting from the
  previous stage's trained weights.

Full reasoning for these design choices is in
[`docs/architecture.md`](docs/architecture.md).

## What's working vs. in progress

Being upfront about this rather than overclaiming:

| Component | Status |
|---|---|
| Manipulation training pipeline (Reach) | ✅ Runs end-to-end, verified |
| Pick/Place, Obstacle-aware training scripts | ✅ Complete and runnable, not yet trained to convergence |
| Obstacle-avoidance safety layer | ✅ Implemented and tested |
| Peg-in-hole | 🔶 Architecture and reward function defined, physics backend pending — this is the acknowledged hardest remaining piece |
| SLAM / Nav2 | ✅ Valid ROS 2 configs, requires a ROS 2 + Gazebo or real-robot environment to run |

See [`docs/results.md`](docs/results.md) for the current honest status of
every stage and how to fill in real numbers as training runs complete.

## Repo structure

```
slam-manip-rl/
├── docs/
│   ├── architecture.md      # system design + reasoning
│   └── results.md           # training status and results log
├── navigation/
│   ├── slam/                # slam_toolbox config
│   ├── nav2_config/         # Nav2 planner/controller/costmap config
│   └── scripts/             # launch scripts
├── manipulation/
│   ├── envs/                # obstacle wrapper, peg-in-hole env
│   ├── train/                # one script per curriculum stage
│   ├── eval/                 # policy evaluation / generalization testing
│   └── policies/            # trained checkpoints land here (gitignored)
├── integration/
│   └── station_handoff.py   # navigate -> manipulate -> navigate control flow
├── configs/
│   └── training_config.yaml # all hyperparameters in one place
└── media/                   # demo gifs/videos go here
```

## Setup

```bash
git clone <this-repo-url>
cd slam-manip-rl
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Navigation components additionally require ROS 2 (Humble or newer) and
Nav2 — see [`navigation/scripts/`](navigation/scripts/) for launch
commands. The manipulation stack has no ROS dependency and runs standalone.

## Running the manipulation curriculum

Each stage is a standalone script that warm-starts from the previous
stage's checkpoint:

```bash
# Stage 1: Reach
python manipulation/train/train_reach.py --timesteps 500000

# Stage 2/3: Pick and Place (warm-starts from Reach)
python manipulation/train/train_pick_place.py \
    --warm-start manipulation/policies/reach_policy.zip \
    --timesteps 1000000

# Stage 4: Obstacle-aware (warm-starts from Pick/Place)
python manipulation/train/train_obstacle_aware.py \
    --warm-start manipulation/policies/pick_place_policy.zip \
    --timesteps 1000000

# Evaluate any checkpoint, including on randomized conditions
python manipulation/eval/evaluate_policy.py \
    --checkpoint manipulation/policies/obstacle_aware_policy.zip \
    --episodes 50
```

## Running navigation

Requires ROS 2 + Nav2 installed, and a Gazebo simulation or real robot with
a LiDAR:

```bash
# Build the map (drive/explore the environment while this runs)
bash navigation/scripts/launch_slam.sh

# Save the map, then bring up navigation against it
ros2 run nav2_map_server map_saver_cli -f ~/maps/my_map
bash navigation/scripts/launch_navigation.sh
```

## Running the full integrated system

```bash
python integration/station_handoff.py --station bin_pickup
```

This drives to the named station via Nav2, then hands off to the trained
manipulation policy for that task. Without ROS 2 installed, the navigation
half no-ops gracefully so you can still test the manipulation handoff logic
in isolation.

## Generalization strategy

Policies are trained with domain randomization (object mass, friction,
initial pose — see `configs/training_config.yaml`) from the earliest
curriculum stage onward, not bolted on at the end. Evaluation is run on
held-out conditions not seen during training (see
`docs/results.md#generalization-tests`) to distinguish real generalization
from memorization of the training distribution.

## License

See [LICENSE](LICENSE).

# System Architecture

## Overview

The system has two independent stacks that share a map and hand off control
at named stations:

```
                  ┌─────────────────────┐
                  │   SLAM (mapping)     │
                  │  slam_toolbox        │
                  └──────────┬───────────┘
                             │ occupancy grid map
                             ▼
                  ┌─────────────────────┐
                  │   Nav2 (navigation)  │
                  │  AMCL + planner +    │
                  │  controller          │
                  └──────────┬───────────┘
                             │ "arrived at station"
                             ▼
                  ┌─────────────────────┐
                  │  integration/        │
                  │  station_handoff.py  │
                  └──────────┬───────────┘
                             │ load checkpoint, run closed-loop
                             ▼
                  ┌─────────────────────┐
                  │  RL manipulation     │
                  │  policy (PPO)        │
                  └─────────────────────┘
```

## Why this split

Navigation and manipulation are solved with fundamentally different tools
for good reason:

- **Navigation** (SLAM + Nav2) is a mature, well-understood problem with
  reliable open-source solutions. There's little value in reinventing it —
  the engineering effort here is *correct configuration*, not *novel
  algorithms*.
- **Manipulation**, especially contact-rich tasks like peg-in-hole, doesn't
  have a reliable classical solution that generalizes across object
  geometries and physical parameters — this is why reinforcement learning
  is the right tool: it can learn behaviors that are difficult to hand-code.

Keeping them as separate stacks that communicate through one narrow
interface (a named station + a go/success signal) means each half can be
developed, tested, and debugged independently.

## Design decisions worth calling out

**Warm-starting between manipulation stages.** Reach → Pick/Place →
Obstacle-aware all load the previous stage's policy weights before
continuing training, rather than training each stage from scratch. This
is both a training-speed decision (large chunks of the behavior are
already learned) and a practical necessity given a short development
timeline.

**Reward shaping + safety shielding for obstacles, not either alone.**
Reward shaping alone can't *guarantee* collision avoidance — it only makes
collisions less likely by making them costly. The safety layer in
`manipulation/envs/obstacle_wrapper.py` hard-blocks any action that would
enter the obstacle's exclusion radius, regardless of what the policy
outputs. This separation (learn efficient behavior / guarantee safety) is
more robust than relying on the reward function to prevent every collision.

**Impedance control for peg-in-hole, not raw torque.** Contact-rich tasks
are dangerous and hard to learn under raw torque control. Having a
compliance controller underneath the policy means the policy only has to
decide *where* to aim, not *how hard* to push — see
`manipulation/envs/peg_in_hole_env.py` for the full reasoning.

**Relative/egocentric observations where possible**, to avoid policies
that memorize one specific layout instead of generalizing to unseen ones.

## What's real vs. reference implementation

| Component | Status |
|---|---|
| Manipulation training scripts (Reach, Pick/Place, Obstacle-aware) | Runnable, tested |
| Obstacle-aware wrapper | Runnable, tested |
| Peg-in-hole environment | Architecture defined, physics backend pending |
| SLAM / Nav2 configs | Valid ROS 2 configuration, requires a ROS 2 + Gazebo/real-robot environment to run |
| `station_handoff.py` | Runnable; navigation half no-ops gracefully without ROS 2 installed, manipulation half is fully functional |

See `docs/results.md` for training results and honest status per stage.

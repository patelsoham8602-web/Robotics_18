# Results

This page tracks what's actually been trained/tested vs. what's designed
but not yet run to convergence. Update the tables below as you train each
stage for real.

## Manipulation curriculum status

| Stage | Status | Result |
|---|---|---|
| 1. Reach | ✅ Pipeline verified | Ran a short (3,000 timestep) training pass to confirm the environment, PPO setup, and checkpoint saving all work end-to-end on `FetchReach-v3`. Full training (500k timesteps) not yet run — expected convergence within ~1 hour on CPU. |
| 2/3. Pick + Place | 🔲 Not yet trained | Script is complete and warm-starts from the Reach checkpoint (`manipulation/train/train_pick_place.py`). Run it once Reach has fully converged. |
| 4. Obstacle-aware | 🔲 Not yet trained | Wrapper and training script complete (`manipulation/envs/obstacle_wrapper.py`). Depends on a converged Pick/Place checkpoint. |
| 5. Peg-in-hole | 🔶 Architecture only | Environment interface and reward function defined in `manipulation/envs/peg_in_hole_env.py`. Physics backend not wired up — this is the highest-effort remaining item; budget the most time here. |

## How to fill this in as you train

For each stage, once trained, record:

```
Stage: <name>
Timesteps trained: <N>
Mean reward (eval, N episodes): <value> +/- <std>
Success rate: <X>/<N>
Training time: <duration, hardware used>
```

And save a training-curve screenshot or a short `.gif`/`.mp4` of the
policy running to `media/`.

## Navigation status

SLAM (`navigation/slam/slam_params.yaml`) and Nav2
(`navigation/nav2_config/nav2_params.yaml`) configs are provided and valid,
but require a ROS 2 + Gazebo simulation or real robot to actually run and
produce a map. Test in Gazebo first:

```
Map built: <yes/no>
Loop closure quality: <notes>
Navigation success rate over N point-to-point trials: <X>/<N>
```

## Generalization tests (once policies are trained)

Report success rate on conditions *not* seen during training —
this is what separates "generalizable" from "memorized":

| Test condition | Success rate |
|---|---|
| Training distribution (baseline) | — |
| Object mass ±50% outside training range | — |
| Unseen obstacle position | — |
| Added external disturbance mid-episode | — |

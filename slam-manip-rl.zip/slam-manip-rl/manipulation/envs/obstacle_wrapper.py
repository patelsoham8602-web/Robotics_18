"""
Gymnasium wrapper that adds obstacle-awareness to any Fetch-style env.

Two layers, deliberately kept separate:
  1. Reward shaping   -- smoothly penalizes getting close to an obstacle,
                          so the policy learns to route around it naturally.
  2. Safety shielding -- hard-blocks any action that would drive the
                          end-effector inside the obstacle's exclusion
                          radius, regardless of what the policy outputs.
                          This is the backup that reward shaping alone
                          cannot guarantee.

Point 2 is what makes this "obstacle-aware" rather than just
"obstacle-discouraged" -- a policy can still be trained sub-optimally and
learn to cut a corner close; the safety layer is what prevents a hard
collision even then.
"""

import numpy as np
import gymnasium as gym


class ObstacleAwareWrapper(gym.Wrapper):
    def __init__(self, env: gym.Env, obstacle_pos=(1.3, 0.6, 0.5),
                 exclusion_radius: float = 0.05, penalty_radius: float = 0.15,
                 penalty_weight: float = 5.0):
        super().__init__(env)
        self.obstacle_pos = np.array(obstacle_pos, dtype=np.float32)
        self.exclusion_radius = exclusion_radius   # hard safety boundary
        self.penalty_radius = penalty_radius        # where reward shaping kicks in
        self.penalty_weight = penalty_weight

    def _gripper_pos(self, obs):
        # Fetch envs expose achieved_goal / observation dict with gripper
        # position embedded in the first 3 values of "observation".
        if isinstance(obs, dict) and "observation" in obs:
            return obs["observation"][:3]
        return obs[:3]

    def step(self, action):
        # --- Safety layer: block motion that would enter the exclusion zone ---
        obs = self.env.unwrapped._get_obs() if hasattr(self.env.unwrapped, "_get_obs") else None
        if obs is not None:
            gripper_pos = self._gripper_pos(obs)
            projected = gripper_pos + np.asarray(action[:3]) * 0.05  # rough step estimate
            dist_to_obstacle = np.linalg.norm(projected - self.obstacle_pos)
            if dist_to_obstacle < self.exclusion_radius:
                action = np.array(action, dtype=np.float32).copy()
                action[:3] = 0.0  # zero out translational motion this step

        obs, reward, terminated, truncated, info = self.env.step(action)

        # --- Reward shaping: smooth penalty as the gripper nears the obstacle ---
        gripper_pos = self._gripper_pos(obs)
        dist = np.linalg.norm(gripper_pos - self.obstacle_pos)
        if dist < self.penalty_radius:
            reward -= self.penalty_weight * (self.penalty_radius - dist)

        info["dist_to_obstacle"] = dist
        return obs, reward, terminated, truncated, info

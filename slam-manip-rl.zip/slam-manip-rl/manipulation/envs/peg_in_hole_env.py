"""
Stage 5: Peg-in-hole -- ARCHITECTURE / WORK IN PROGRESS.

This is the hardest task in the curriculum and, honestly, not something
that reliably converges in a few days of solo work -- it normally needs
days of reward-tuning even for experienced RL practitioners. This file
defines the intended structure so the design is clear and the next
iteration has a concrete starting point, rather than pretending a
fully-converged policy exists.

Key design decisions (why, not just what):

1. Action space: task-space impedance/compliance control (target pose +
   stiffness), NOT raw joint torques. Raw torque control makes contact
   physically risky and much harder to learn -- an impedance controller
   underneath the policy makes contact safe by construction, so the RL
   policy only has to learn *where* to aim, not *how hard* to push.

2. Observation: must include wrist force/torque sensor readings. Once the
   peg is near/inside the hole, vision is occluded by the peg itself --
   without force feedback the policy is trying to solve blind insertion,
   which is far harder than necessary.

3. Reward: dense shaping (insertion depth + lateral alignment error) plus
   a force-magnitude penalty to discourage jamming, with a sparse bonus
   for full insertion. Pure sparse reward (1 on success, 0 otherwise) is
   realistic for a well-tuned setup with far more training time than a
   short competition window allows.

4. Recommended technique: residual RL -- learn a residual correction on
   top of a scripted/PD insertion controller, rather than learning
   insertion from scratch. This converges dramatically faster because the
   policy only has to learn the "hard part" (the last few mm of
   alignment), not full reaching + insertion end to end.

Status: environment and reward function defined below; NOT yet trained to
convergence. See docs/results.md for the partial training curve and an
honest account of where this stage stands.
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces


class PegInHoleEnv(gym.Env):
    """Skeleton env. Physics/contact simulation intentionally left for the
    next iteration -- see class docstring above for the reasoning behind
    each design choice, which is the part worth reviewing right now."""

    def __init__(self, hole_diameter=0.02, peg_diameter=0.018, insertion_depth=0.05):
        super().__init__()
        self.hole_diameter = hole_diameter
        self.peg_diameter = peg_diameter
        self.insertion_depth = insertion_depth

        # Action: [dx, dy, dz, stiffness] -- target pose delta + compliance gain
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(4,), dtype=np.float32)

        # Observation: peg pose (7) + wrist force/torque (6) + hole pose (7)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(20,), dtype=np.float32)

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        raise NotImplementedError(
            "Physics backend not wired up yet -- plug in MuJoCo/Isaac contact "
            "simulation here. This class defines the intended interface only."
        )

    def step(self, action):
        raise NotImplementedError("See reset(); physics backend pending.")

    def _compute_reward(self, insertion_depth, lateral_error, contact_force):
        """Dense reward: reward insertion progress, penalize misalignment
        and excessive contact force (which indicates jamming)."""
        depth_term = insertion_depth / self.insertion_depth
        alignment_term = -lateral_error * 10.0
        force_penalty = -0.01 * max(0.0, contact_force - 5.0)  # allow gentle contact
        success_bonus = 10.0 if insertion_depth >= self.insertion_depth else 0.0
        return depth_term + alignment_term + force_penalty + success_bonus

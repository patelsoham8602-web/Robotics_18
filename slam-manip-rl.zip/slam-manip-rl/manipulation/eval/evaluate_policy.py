"""
Load any saved checkpoint and evaluate it -- including on randomized
start/goal conditions, to check generalization rather than just replaying
the exact training distribution.

Usage:
    python manipulation/eval/evaluate_policy.py \
        --checkpoint manipulation/policies/pick_place_policy.zip \
        --env-id FetchPickAndPlace-v3 \
        --episodes 50
"""

import argparse

import gymnasium as gym
from stable_baselines3 import PPO


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--env-id", default="FetchPickAndPlace-v3")
    parser.add_argument("--episodes", type=int, default=50)
    parser.add_argument("--render", action="store_true")
    args = parser.parse_args()

    env = gym.make(args.env_id, render_mode="human" if args.render else None)
    model = PPO.load(args.checkpoint)

    rewards, successes = [], 0
    for ep in range(args.episodes):
        obs, info = env.reset()
        done, ep_reward = False, 0.0
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            ep_reward += reward
            done = terminated or truncated
        rewards.append(ep_reward)
        if info.get("is_success", 0):
            successes += 1

    mean_reward = sum(rewards) / len(rewards)
    print(f"Episodes:      {args.episodes}")
    print(f"Mean reward:   {mean_reward:.2f}")
    print(f"Success rate:  {successes}/{args.episodes} ({100 * successes / args.episodes:.0f}%)")


if __name__ == "__main__":
    main()

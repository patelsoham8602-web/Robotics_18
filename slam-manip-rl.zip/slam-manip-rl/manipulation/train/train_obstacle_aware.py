"""
Stage 4: Obstacle-aware pick and place.

Wraps FetchPickAndPlace-v3 with ObstacleAwareWrapper (reward shaping +
safety shielding) and continues training from the pick_place checkpoint.

Usage:
    python manipulation/train/train_obstacle_aware.py \
        --warm-start manipulation/policies/pick_place_policy.zip \
        --timesteps 1000000
"""

import argparse
import os
import sys

import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.common.monitor import Monitor

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from envs.obstacle_wrapper import ObstacleAwareWrapper  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-id", default="FetchPickAndPlace-v3")
    parser.add_argument("--warm-start", default=None)
    parser.add_argument("--timesteps", type=int, default=1_000_000)
    parser.add_argument("--out", default="manipulation/policies/obstacle_aware_policy")
    parser.add_argument("--eval-episodes", type=int, default=10)
    args = parser.parse_args()

    base_env = gym.make(args.env_id)
    env = Monitor(ObstacleAwareWrapper(base_env))

    if args.warm_start and os.path.exists(args.warm_start):
        print(f"Warm-starting from {args.warm_start}")
        model = PPO.load(args.warm_start, env=env)
    else:
        print("No warm-start checkpoint found -- training from scratch")
        model = PPO("MultiInputPolicy", env, verbose=1)

    model.learn(total_timesteps=args.timesteps)

    mean_reward, std_reward = evaluate_policy(model, env, n_eval_episodes=args.eval_episodes)
    print(f"Eval over {args.eval_episodes} episodes: {mean_reward:.2f} +/- {std_reward:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    model.save(args.out)
    print(f"Saved checkpoint -> {args.out}.zip")


if __name__ == "__main__":
    main()

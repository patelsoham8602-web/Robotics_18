"""
Stage 2 + 3: Pick and Place.

Warm-starts from the Reach checkpoint. FetchPickAndPlace-v3 already scores
reward on: distance to object, successful grasp, and placement accuracy at
the target -- so pick and place are trained together here as one curriculum
stage rather than two, since the environment's reward already covers both.

Usage:
    python manipulation/train/train_pick_place.py \
        --warm-start manipulation/policies/reach_policy.zip \
        --timesteps 1000000
"""

import argparse
import os

import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.common.monitor import Monitor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-id", default="FetchPickAndPlace-v3")
    parser.add_argument("--warm-start", default=None,
                         help="Path to a previous-stage checkpoint (.zip) to continue training from")
    parser.add_argument("--timesteps", type=int, default=1_000_000)
    parser.add_argument("--out", default="manipulation/policies/pick_place_policy")
    parser.add_argument("--eval-episodes", type=int, default=10)
    args = parser.parse_args()

    env = Monitor(gym.make(args.env_id))

    if args.warm_start and os.path.exists(args.warm_start):
        print(f"Warm-starting from {args.warm_start}")
        model = PPO.load(args.warm_start, env=env)
    else:
        print("No warm-start checkpoint found -- training from scratch")
        model = PPO("MultiInputPolicy", env, verbose=1)

    model.learn(total_timesteps=args.timesteps)

    mean_reward, std_reward = evaluate_policy(model, env, n_eval_episodes=args.eval_episodes)
    print(f"Eval over {args.eval_episodes} episodes: {mean_reward:.2f} +/- {std_reward:.2f}")

    # Report success rate too -- more meaningful than mean reward for this task
    successes = 0
    for _ in range(args.eval_episodes):
        obs, info = env.reset()
        done = False
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
        if info.get("is_success", 0):
            successes += 1
    print(f"Success rate: {successes}/{args.eval_episodes}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    model.save(args.out)
    print(f"Saved checkpoint -> {args.out}.zip")


if __name__ == "__main__":
    main()

"""
Stage 1: Reach.

Trains a PPO policy to move a simulated robot arm's end-effector to a
target point. This is the foundation policy that later stages (pick,
place, obstacle-aware, peg-in-hole) warm-start from.

Usage:
    python manipulation/train/train_reach.py --timesteps 500000

Fast pipeline check (few minutes, undertrained policy, just proves it runs):
    python manipulation/train/train_reach.py --timesteps 5000
"""

import argparse
import os

import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.common.monitor import Monitor


def build_env(env_id: str) -> gym.Env:
    """Try the full Fetch robot arm first; fall back to the lightweight
    Reacher env if gymnasium-robotics / its MuJoCo assets aren't available.
    Both expose the same Gymnasium API, so training code doesn't change."""
    try:
        import gymnasium_robotics  # noqa: F401
        env = gym.make(env_id)
    except Exception:
        print(f"[warn] Falling back to Reacher-v5 (could not build {env_id})")
        env = gym.make("Reacher-v5")
    return Monitor(env)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-id", default="FetchReach-v3")
    parser.add_argument("--timesteps", type=int, default=500_000)
    parser.add_argument("--out", default="manipulation/policies/reach_policy")
    parser.add_argument("--eval-episodes", type=int, default=10)
    args = parser.parse_args()

    env = build_env(args.env_id)
    print(f"Observation space: {env.observation_space}")
    print(f"Action space:      {env.action_space}")

    model = PPO("MultiInputPolicy" if isinstance(env.observation_space, gym.spaces.Dict)
                else "MlpPolicy", env, verbose=1)
    model.learn(total_timesteps=args.timesteps)

    mean_reward, std_reward = evaluate_policy(model, env, n_eval_episodes=args.eval_episodes)
    print(f"Eval over {args.eval_episodes} episodes: {mean_reward:.2f} +/- {std_reward:.2f}")

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    model.save(args.out)
    print(f"Saved checkpoint -> {args.out}.zip")


if __name__ == "__main__":
    main()

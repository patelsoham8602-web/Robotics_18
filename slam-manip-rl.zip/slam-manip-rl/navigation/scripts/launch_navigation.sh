#!/bin/bash
# Launch Nav2 for point-to-point navigation against a previously saved map.
# Requires: ROS 2, Nav2, a saved map.yaml from launch_slam.sh.

ros2 launch nav2_bringup bringup_launch.py \
    map:=~/maps/my_map.yaml \
    params_file:=../nav2_config/nav2_params.yaml \
    use_sim_time:=false

# Send a navigation goal, e.g. from the command line:
#   ros2 topic pub /goal_pose geometry_msgs/PoseStamped "{...}"
# or use Nav2's action interface (NavigateToPose) programmatically --
# see integration/station_handoff.py for how this repo does that.

#!/bin/bash
# Launch SLAM mapping (requires ROS 2 + slam_toolbox installed).
# Run this while driving/exploring the environment (manually or via a
# frontier-exploration node) to build the occupancy grid map.

ros2 launch slam_toolbox online_async_launch.py \
    params_file:=../slam/slam_params.yaml \
    use_sim_time:=false

# Once mapping is complete, save the map:
#   ros2 run nav2_map_server map_saver_cli -f ~/maps/my_map
